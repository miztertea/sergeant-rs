top-level readme
